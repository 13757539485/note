package com.cariad.bluetooth_base

import android.bluetooth.BluetoothSocket
import java.util.UUID


interface BluetoothListener {
    fun onStart()
    fun onMsgRecv(socket: BluetoothSocket?, msg: String)
    fun onError(error: String)
    fun onConnected(msg: String)
}
