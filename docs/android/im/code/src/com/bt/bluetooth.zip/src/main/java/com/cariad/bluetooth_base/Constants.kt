package com.cariad.bluetooth_base

import java.net.NetworkInterface
import java.util.UUID
import java.util.regex.Pattern

val BLUE_UUID: UUID = UUID.fromString("00001101-2300-1000-8000-00815F9B34FB")
const val SERVER_MODEL = "V2241A" // ITX-3588J SM-T860 AOSP on walleye
const val sKeyInterfaceName = "wlan"

fun getIPAddress(): String? {
    try {
        val interfaces = NetworkInterface.getNetworkInterfaces()
        while (interfaces.hasMoreElements()) {
            val networkInterface = interfaces.nextElement()
            if (networkInterface.name.startsWith(sKeyInterfaceName)) {
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val inetAddress = addresses.nextElement()
                    if (!inetAddress.isLoopbackAddress && !inetAddress.isLinkLocalAddress
                        && inetAddress.isSiteLocalAddress
                    ) {
                        return inetAddress.hostAddress
                    }
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return null
}

fun isIPv4Address(ipString: String): Boolean {
    // IPv4 地址正则表达式，匹配形如 "0.0.0.0" 至 "255.255.255.255" 的格式
    val ipv4Regex =
        "^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"
    val pattern = Pattern.compile(ipv4Regex)
    return pattern.matcher(ipString).matches()
}


