package com.cariad.bluetooth_base

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@SuppressLint("MissingPermission")
class BtServer(private val listener: BluetoothListener?) {
    private val TAG = "BtServer"
    private val bluetooth by lazy { BluetoothAdapter.getDefaultAdapter() }
    private var serverSocket: BluetoothServerSocket? = null
    private var handleSocket: HandleSocket? = null
    private val mainScope by lazy { MainScope() }

    init {
        listener?.onStart()
        serverSocket = bluetooth.listenUsingInsecureRfcommWithServiceRecord(TAG, BLUE_UUID)
    }

    @Volatile
    private var isStart: Boolean = false

    /**
     * java、kt代码可调用，启动蓝牙服务端等待
     */
    fun start() {
        mainScope.launch {
            startServer()
        }
    }

    /**
     * kt代码调用，启动蓝牙服务端等待
     */
    private suspend fun startServer() = withContext(Dispatchers.IO) {
        Log.i(TAG, "startServer $serverSocket")
        isStart = true
        while (isStart) {
            try {
                val socket = serverSocket?.accept()
                socket?.also {
                    handleSocket = HandleSocket(it, listener)
                    withContext(Dispatchers.Main) {
                        listener?.onConnected(it.remoteDevice.name)
                    }
                    Log.i(TAG, "start server success")
                    handleSocket?.start()
                }
            } catch (e: Exception) {
                Log.d(TAG, "blue socket accept fail: ${e.message}")
                withContext(Dispatchers.Main) {
                    listener?.onError("blue socket accept fail: ${e.message}")
                }
            }
        }
    }

    /**
     * 发送消息
     */
    fun sendMsg(msg: String) {
        if (!isStart) {
            Log.d(TAG, "server is not start")
            return
        }
        handleSocket?.sendMsg(msg)
        Log.i(TAG, "sendMsg：$msg")
    }

    /**
     * 断开连接和释放资源
     */
    fun close() {
        isStart = false
        handleSocket?.cancel()

        try {
            serverSocket?.close()
        } catch (e: Exception) {
            listener?.onError("serverSocket close error: $e")
        }
        Log.i(TAG, "close server")
    }
}