package com.cariad.bluetooth_base

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@SuppressLint("MissingPermission")
class BtClient(
    private val bluetoothDevice: BluetoothDevice,
    private val listener: BluetoothListener?
) {
    private val TAG = "BtClient"
    private val bluetooth by lazy { BluetoothAdapter.getDefaultAdapter() }
    private val socket: BluetoothSocket? by lazy {
        bluetoothDevice.createRfcommSocketToServiceRecord(BLUE_UUID)
    }
    private val mainScope by lazy { MainScope() }

    init {
        listener?.onStart()
    }

    private var handleSocket: HandleSocket? = null

    /**
     * java、kt代码可调用，启动蓝牙连接
     */
    fun start() {
        mainScope.launch {
            startClient()
        }
    }

    /**
     * kt代码调用，启动蓝牙连接
     */
    private suspend fun startClient() = withContext(Dispatchers.IO) {
        bluetooth.cancelDiscovery()
        try {
            socket?.run {
                connect()
                remoteDevice?.let {
                    withContext(Dispatchers.Main) {
                        listener?.onConnected(it.name)
                    }
                }
                Log.i(TAG, "start client success")
                handleSocket = HandleSocket(this, listener)
                handleSocket?.start()
            }
        } catch (e: Exception) {
            Log.d(TAG, "start client error: ${e.message}")
            withContext(Dispatchers.Main) {
                listener?.onError("start client error: ${e.message.toString()}")
            }
        }
    }

    /**
     * 发送消息
     */
    fun sendMsg(msg: String) {
        handleSocket?.sendMsg(msg)
        Log.i(TAG, "sendMsg：$msg $handleSocket")
    }

    /**
     * 断开连接和释放资源
     */
    fun close() {
        Log.i(TAG, "close client")
        handleSocket?.cancel()
    }
}