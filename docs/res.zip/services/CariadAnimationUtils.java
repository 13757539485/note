package com.cariad.m2;

import android.graphics.Rect;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;

import com.android.internal.policy.SystemBarUtils;

public class CariadAnimationUtils {
    private static final long SPLIT_LAUNCHER_DURATION = 250L;
    private static final long SPLIT_APP_DURATION = 350L;

    public static Animation getSplitAnimation(boolean isLauncherApp, boolean enter, Rect appBound) {
        return isLauncherApp ? getSplitLauncherAnimation(enter) : getSplitOtherAppAnimation(enter, appBound);
    }

    private static Animation getSplitLauncherAnimation(boolean enter) {
        float startAlpha = enter ? 0f : 1f;
        float endAlpha = enter ? 1f : 0f;
        AlphaAnimation animation = new AlphaAnimation(startAlpha, endAlpha);
        animation.setDuration(SPLIT_LAUNCHER_DURATION);
        animation.setFillAfter(true);
        animation.setFillEnabled(true);
        return animation;
    }

    private static Animation getSplitOtherAppAnimation(boolean enter, Rect appBound) {
        AnimationSet set = new AnimationSet(false);
        float startAlpha = enter ? 0f : 1f;
        float endAlpha = enter ? 1f : 0f;
        AlphaAnimation alphaAnimation = new AlphaAnimation(startAlpha, endAlpha);
        alphaAnimation.setDuration(enter ? SPLIT_LAUNCHER_DURATION : SPLIT_APP_DURATION);
        float startScale = enter ? 0f : 1f;
        float endScale = enter ? 1f : 0f;
        float centerX = appBound.centerX();
        float centerY = appBound.centerX();
        ScaleAnimation scaleAnimation = new ScaleAnimation(startScale, endScale, startScale,
                endScale, centerX, centerY);
        scaleAnimation.setDuration(SPLIT_APP_DURATION);

        RoundCornerAnimation roundCornerAnimation = new RoundCornerAnimation(SystemBarUtils.SPLIT_WINDOW_CORNER_RADIUS,
                SystemBarUtils.SPLIT_WINDOW_CORNER_RADIUS);
        roundCornerAnimation.setDuration(SPLIT_APP_DURATION);

        set.addAnimation(alphaAnimation);
        set.addAnimation(scaleAnimation);
        set.addAnimation(roundCornerAnimation);
        set.setFillAfter(true);
        set.setFillEnabled(true);
        return set;
    }
}
