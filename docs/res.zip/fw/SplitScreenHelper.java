package com.cariad.m2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;


/**
 * @hide
 */
public class SplitScreenHelper {
    private static String TAG = "SplitScreenHelper";
    public static final String PUSH_OUT_ACTION = "PUSH_OUT_ACTION";
    public static final String PHONE_APP_TO_FLOAT_WINDOW = "PHONE_APP_TO_FLOAT_WINDOW";
    public static final String START_TASK_ACTION = "START_TASK_ACTION";

    public static final String EXIT_SPLIT_SCREEN_ACTION = "EXIT_SPLIT_SCREEN_ACTION";
    public static final String START_SPLIT_SCREEN_ACTION = "START_SPLIT_SCREEN_ACTION";
    public static final String START_CHANGE_SCREEN_ACTION = "START_CHANGE_SCREEN_ACTION";

    public static final String START_FULL_SCREEN_ACTION = "START_FULL_SCREEN_ACTION";


    public static final String MAIN_ACTIVITY_CLS = "com.cariad.m2.quick_step.page.MainActivity";
    public static final String SIDE_ACTIVITY_CLS = "com.cariad.m2.quick_step.page.SideActivity";
    public static final String CAR_LINK_LAUNCHER_PKG = "com.cariad.m2.car_link_launcher";

    public static final String PKG_KEY = "PKG";
    public static final String PKG_LEFT_KEY = "PKG_LEFT_KEY";
    public static final String PKG_RIGHT_KEY = "PKG_RIGHT_KEY";
    public static final String IS_LEFT_KEY = "IS_LEFT_KEY";
    public static final Uri CONTENT_URI = Uri.parse("content://" + CAR_LINK_LAUNCHER_PKG + "/quick_step");

    /**
     * 推出
     *
     * @param context
     */
    public static void pushOut(Context context,String pkg,boolean isLeft) {
        boolean isChange = queryIsChange(context);
        isLeft = isChange ? !isLeft : isLeft;
        ComponentName component;
        if (isLeft){
            component = new ComponentName(CAR_LINK_LAUNCHER_PKG, MAIN_ACTIVITY_CLS);
        }else {
            component = new ComponentName(CAR_LINK_LAUNCHER_PKG, SIDE_ACTIVITY_CLS);
        }
        Intent targetIntent = new Intent(Intent.ACTION_MAIN);
        targetIntent.setComponent(component);
        targetIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(targetIntent);

        Intent intent = new Intent();
        intent.setAction(PUSH_OUT_ACTION);
        intent.putExtra(PKG_KEY, pkg);
        intent.putExtra(IS_LEFT_KEY, isLeft);
        context.sendBroadcast(intent);
    }

    /**
     * 直接根据包名开启app分屏任务
     * @param context
     * @param leftPkg
     * @param rightPkg
     */
    public static void startTask(Context context, String leftPkg,String rightPkg) {
        Intent intent = new Intent();
        intent.setAction(START_TASK_ACTION);
        intent.putExtra(PKG_LEFT_KEY, leftPkg);
        intent.putExtra(PKG_RIGHT_KEY, rightPkg);
        context.sendBroadcast(intent);
    }

    /**
     * 手机投屏app转悬浮窗
     * @param context
     */
    public static void phoneApp2FloatWindow(Context context) {
        Intent intent = new Intent();
        intent.setAction(PHONE_APP_TO_FLOAT_WINDOW);
        context.sendBroadcast(intent);
    }

    /**
     * 退出分屏(另一个应用进入全屏状态)
     *
     * @param context
     * @param pkg
     */
    public static void exitSplitScreen(Context context, String pkg) {
        Intent intent = new Intent();
        intent.setAction(EXIT_SPLIT_SCREEN_ACTION);
        intent.putExtra(PKG_KEY, pkg);
        context.sendBroadcast(intent);
    }

    /**
     * 交换
     *
     * @param context
     * @param pkg
     */
    public static void changeScreen(Context context, String pkg) {
        Intent intent = new Intent();
        intent.setAction(START_CHANGE_SCREEN_ACTION);
        intent.putExtra(PKG_KEY, pkg);
        context.sendBroadcast(intent);
    }

    /**
     * 应用开启全屏
     *
     * @param context
     * @param pkg
     */
    public static void startFullScreen(Context context, String pkg) {
        Intent intent = new Intent();
        intent.setAction(START_FULL_SCREEN_ACTION);
        intent.putExtra(PKG_KEY, pkg);
        context.sendBroadcast(intent);
    }

    /**
     * 开启分屏
     *
     * @param pkg       要开启分屏的应用包名
     * @param isLeft true:left,false:right
     */
    public static void startSplitScreen(Context context, String pkg, boolean isLeft) {
        Intent intent = new Intent();
        intent.setAction(START_SPLIT_SCREEN_ACTION);
        intent.putExtra(PKG_KEY, pkg);
        intent.putExtra(IS_LEFT_KEY, isLeft);
        context.sendBroadcast(intent);
    }

    /**
     * 开启分屏 可以传递一些bundle 自定义一些业务能力
     * @param context
     * @param pkg
     * @param isLeft
     * @param key
     * @param bundle
     */
    public static void startSplitScreen(Context context, String pkg, boolean isLeft, String key, Bundle bundle) {
        Intent intent = new Intent();
        intent.setAction(START_SPLIT_SCREEN_ACTION);
        intent.putExtra(PKG_KEY, pkg);
        intent.putExtra(IS_LEFT_KEY, isLeft);
        intent.putExtra(key, bundle);
        context.sendBroadcast(intent);

    }


    @SuppressLint("Range")
    private static boolean queryIsChange(Context context) {
        Cursor cursor = context.getContentResolver().query(CONTENT_URI, (String[])null, "isChange", null, null);
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    boolean isChange = cursor.getInt(cursor.getColumnIndex("isChange")) == 1;
                    return isChange;
                }
            } finally {
                cursor.close();
            }
        }
        return false;
    }
}
