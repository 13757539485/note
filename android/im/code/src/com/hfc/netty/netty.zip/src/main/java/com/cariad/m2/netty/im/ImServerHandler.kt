package com.cariad.m2.netty.im

import android.graphics.BitmapFactory
import com.cariad.m2.netty.base.BaseHandler
import com.cariad.m2.netty.base.SimpleChannelHandler
import com.cariad.m2.netty.decoder.ByteArrayMessageDecoder
import com.cariad.m2.netty.encoder.ByteArrayMessageEncoder
import com.cariad.m2.netty.pack.ByteArrayMessage
import io.netty.channel.ChannelHandlerContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImServerHandler : BaseHandler<ImListener>() {
    private val TAG = "ImServerHandler"

    fun startServer(port: Int = 1088) {
        buildTcpServer(port, exce = {
            listener?.channelInActive("ConnectException")
        }) { socketChannel ->
            socketChannel.pipeline().addLast(ByteArrayMessageEncoder())
            socketChannel.pipeline().addLast(ByteArrayMessageDecoder())
            socketChannel.pipeline()
                .addLast(object :
                    SimpleChannelHandler<ByteArrayMessage, ImListener>(
                        listener,
                        this
                    ) {
                    override fun messageReceived(
                        ctx: ChannelHandlerContext,
                        msg: ByteArrayMessage
                    ) {
                        msg.data.let { data ->
                            when (msg.type) {
                                0 -> {
                                    listener?.messageReceived(
                                        BitmapFactory.decodeByteArray(
                                            data,
                                            0,
                                            msg.length
                                        )
                                    )
                                }

                                1 -> {
                                    listener?.messageReceived(String(data))
                                }

                                else -> { listener?.messageReceived("not support the type") }
                            }
                        } ?: {
                            listener?.messageReceived("the data is null")
                        }
                    }
                })
        }
    }

    fun sendMsg(msg: ByteArrayMessage) {
        checkHandlerContext {
           mainScope.launch {
                withContext(Dispatchers.IO) {
                    it.writeAndFlush(msg)
                }
            }
        }
    }

    fun sendStr(msg: String) {
        checkHandlerContext {
            mainScope.launch {
                withContext(Dispatchers.IO) {
                    val bytes = msg.toByteArray()
                    it.writeAndFlush(ByteArrayMessage(bytes, bytes.size, 1))
                }
            }
        }
    }
}