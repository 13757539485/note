package com.cariad.m2.netty.im

import android.graphics.BitmapFactory
import android.util.Log
import com.cariad.m2.netty.base.BaseHandler
import com.cariad.m2.netty.base.SimpleChannelHandler
import com.cariad.m2.netty.decoder.ByteArrayMessageDecoder
import com.cariad.m2.netty.encoder.ByteArrayMessageEncoder
import com.cariad.m2.netty.pack.ByteArrayMessage
import io.netty.channel.ChannelHandlerContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImClientHandler : BaseHandler<ImListener>() {
    fun startClient(ip: String, port: Int = 1088) {
        buildTcpClient(ip, port) { socketChannel ->
            socketChannel.pipeline().addLast(ByteArrayMessageEncoder())
            socketChannel.pipeline().addLast(ByteArrayMessageDecoder())
            socketChannel.pipeline()
                .addLast(object : SimpleChannelHandler<ByteArrayMessage,
                        ImListener>(listener, this) {
                    override fun messageReceived(
                        ctx: ChannelHandlerContext?,
                        msg: ByteArrayMessage
                    ) {
                        msg.data.let { data ->
                            when (msg.type) {
                                0 -> {
                                    mainScope.launch {
                                        listener?.messageReceived(
                                            BitmapFactory.decodeByteArray(
                                                data,
                                                0,
                                                msg.length
                                            )
                                        )
                                    }
                                }

                                1 -> {
                                    mainScope.launch {
                                        listener?.messageReceived(String(data))
                                    }
                                }

                                else -> {
                                    mainScope.launch {
                                        listener?.messageReceived("not support the type")
                                    }
                                }
                            }
                        }
                    }
                })
        }
    }

    fun sendMsg(msg: List<ByteArrayMessage>) {
        checkHandlerContext { chc ->
            msg.forEach {
                chc.writeAndFlush(it)
            }
        }
    }

    fun sendMsg(msg: ByteArrayMessage) {
        checkHandlerContext { chc ->
            chc.writeAndFlush(msg)
        }
    }

    fun sendStr(msg: String) {
        checkHandlerContext { chc ->
            val bytes = msg.toByteArray()
            chc.writeAndFlush(ByteArrayMessage(bytes, bytes.size, 1))
        }
    }
}