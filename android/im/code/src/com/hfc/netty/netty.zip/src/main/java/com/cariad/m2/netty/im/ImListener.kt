package com.cariad.m2.netty.im

import android.graphics.Bitmap
import com.cariad.m2.netty.base.SimpleListener

interface ImListener: SimpleListener {
    fun messageReceived(bitmap: Bitmap)

    fun messageReceived(msg: String)
}