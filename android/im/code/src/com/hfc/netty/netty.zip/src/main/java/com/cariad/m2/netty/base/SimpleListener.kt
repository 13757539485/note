package com.cariad.m2.netty.base

interface SimpleListener {
    fun channelActive()
    fun channelInActive(msg: String)
}