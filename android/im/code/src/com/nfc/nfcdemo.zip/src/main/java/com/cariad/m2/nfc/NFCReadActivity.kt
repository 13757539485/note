package com.cariad.m2.nfc

import android.content.Intent
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.cariad.m2.nfc.databinding.ActivityNfcreadBinding
import com.cariad.m2.nfc_base.NfcManager
import java.io.UnsupportedEncodingException
import java.nio.charset.Charset


@RequiresApi(Build.VERSION_CODES.TIRAMISU)
class NFCReadActivity : AppCompatActivity() {
    private val binding by lazy { ActivityNfcreadBinding.inflate(layoutInflater) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    public override fun onResume() {
        super.onResume()
//        NfcManager.enableNfcDispatcher(this)
        NfcManager.enableNfcReaderMode(this) {
            it.let { result ->
                runOnUiThread { binding.statusTextView.text = result }
            }
        }
    }

    public override fun onPause() {
        super.onPause()
        NfcManager.disableNfcDispatcher(this)
//        NfcManager.disableNfcReaderMode(this)
    }

    private fun handleIntent(intent: Intent?) {
        intent?.let {
            if (NfcAdapter.ACTION_NDEF_DISCOVERED == it.action) {
                it.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)?.let { rawMessages ->
                    rawMessages.getOrNull(0)?.let {
                        NfcManager.parseNdefMessagesToText(rawMessages[0] as NdefMessage) { result ->
                            runOnUiThread { binding.statusTextView.text = result }
                        }
                    }
                }
            }
        }
    }
}