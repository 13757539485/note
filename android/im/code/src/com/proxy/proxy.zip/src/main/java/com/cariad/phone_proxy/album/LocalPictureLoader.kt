package com.cariad.phone_proxy.album

import android.annotation.SuppressLint
import android.database.Cursor
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.cariad.m2.netty.pack.ByteArrayMessage
import com.cariad.phone_proxy.base.ProxyApplication
import com.cariad.phone_proxy.utils.toast
import com.hjq.permissions.OnPermissionCallback
import com.hjq.permissions.Permission
import com.hjq.permissions.XXPermissions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.asFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

@SuppressLint("DiscouragedPrivateApi")
object LocalPictureLoader {
    private val TAG = "LocalPictureLoader"
    private val cacheMedia: MutableList<Bitmap> = mutableListOf()
    private val oriPaths: MutableList<String> = mutableListOf()

    var isReady: Boolean = false

    fun addCache(bitmap: Bitmap) {
        cacheMedia.add(bitmap)
    }

    fun getCache() = cacheMedia

    fun init(activity: AppCompatActivity) {
        XXPermissions.with(activity)
            .permission(Permission.READ_MEDIA_IMAGES)
            .request(object : OnPermissionCallback {

                @RequiresApi(Build.VERSION_CODES.TIRAMISU)
                override fun onGranted(permissions: MutableList<String>, allGranted: Boolean) {
                    if (!allGranted) {
                        activity.toast("获取部分权限成功，但部分权限未正常授予")
                        return
                    }
                    load(activity)
                }

                override fun onDenied(permissions: MutableList<String>, doNotAskAgain: Boolean) {
                    activity.toast("获取权限失败或被永久拒绝授权，请手动授予位和附近的设备权限")
                    XXPermissions.startPermissionActivity(activity, permissions)
                }
            })
    }

    suspend fun LocalPictureLoader.mediaToByteArrayMessage(quality: Int = 80): List<ByteArrayMessage> {
        if (!isReady) {
            Log.e(TAG, "picture data is not ready")
            return mutableListOf()
        }
        return cacheMedia.asFlow()
            .flowOn(Dispatchers.IO).map { bitmap ->
            ByteArrayOutputStream().use { baos ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos)
                ByteArrayMessage(baos.toByteArray(), baos.size(), 0)
            }
        }.toList()
    }

    fun gainOriImgPath() = oriPaths

    private fun load(activity: AppCompatActivity) {
        cacheMedia.clear()
        oriPaths.clear()
        isReady = false
        val selection = MediaStore.Images.Media.DATA + " NOT LIKE ? AND " +
                MediaStore.Images.Media.DATA + " NOT LIKE ?"
        val selectionArgs = arrayOf("%car_image%", "%aigc%")
        val data = activity.contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(
            //文件存储路径
            MediaStore.Images.Media.DATA,
            //文件名称
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            //文件目录id
            MediaStore.Images.Media.BUCKET_ID,
            //文件的创建时间
            MediaStore.Images.Media.DATE_TAKEN,
            //文件大小
            MediaStore.Images.Media.SIZE
        ),
            selection, selectionArgs, MediaStore.Images.Media.DATE_MODIFIED + " DESC")
        data?.let { imageCursor ->
            ProxyApplication.mainScope.launch {
                val paths = withContext(Dispatchers.IO) {
                    fetchPaths(imageCursor)
                }
                oriPaths.addAll(paths)
                ImageLoader.createBitmapList(
                    activity,
                    paths,
                    cacheMedia,
                )
            }
        }
    }

    private suspend fun fetchPaths(imageCursor: Cursor) = withContext(Dispatchers.IO) {
        val dataColumnIndex = imageCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
        flow {
            if (imageCursor.moveToFirst()) {
                do {
                    val data = imageCursor.getString(dataColumnIndex)
                    emit(data)
                } while (imageCursor.moveToNext())
            }
        }.filterNotNull()
            .toList()
            .also {
                if (!imageCursor.isClosed) {
                    imageCursor.close()
                }
            }
    }
}