package com.cariad.phone_proxy.album

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Environment
import android.util.Log
import android.util.SparseArray
import com.cariad.phone_proxy.base.CACHE_DIRECTORY
import com.cariad.phone_proxy.base.FlowBus
import com.cariad.phone_proxy.base.ProxyApplication
import com.cariad.phone_proxy.event.EVENT_CACHE_MEDIA
import com.cariad.phone_proxy.utils.IOUtils
import com.cariad.phone_proxy.utils.dp2px
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.RejectedExecutionHandler
import java.util.concurrent.SynchronousQueue
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * 图片加载器
 */
object ImageLoader {
    private const val TAG = "ImageLoader"
    private var root: File? = null
    private const val CORE_POOL_SIZE = 1
    private const val MAXIMUM_POOL_SIZE = 20
    private const val BACKUP_POOL_SIZE = 5
    private const val KEEP_ALIVE_SECONDS = 3
    private var sBackupExecutor: ThreadPoolExecutor? = null
    private var sBackupExecutorQueue: LinkedBlockingQueue<Runnable>? = null
    private val sThreadFactory: ThreadFactory = object : ThreadFactory {
        private val mCount = AtomicInteger(1)
        override fun newThread(r: Runnable): Thread {
            return Thread(r, "ImageLoader #" + mCount.getAndIncrement())
        }
    }
    private val sRunOnSerialPolicy: RejectedExecutionHandler = object : RejectedExecutionHandler {
        override fun rejectedExecution(r: Runnable, e: ThreadPoolExecutor) {
            Log.w(TAG, "Exceeded ThreadPoolExecutor pool size")
            // As a last ditch fallback, run it on an executor with an unbounded queue.
            // Create this executor lazily, hopefully almost never.
            synchronized(this) {
                if (sBackupExecutor == null) {
                    sBackupExecutorQueue = LinkedBlockingQueue()
                    sBackupExecutor = ThreadPoolExecutor(
                        BACKUP_POOL_SIZE, BACKUP_POOL_SIZE, KEEP_ALIVE_SECONDS.toLong(),
                        TimeUnit.SECONDS, sBackupExecutorQueue, sThreadFactory
                    )
                    sBackupExecutor!!.allowCoreThreadTimeOut(true)
                }
            }
            sBackupExecutor!!.execute(r)
        }
    }

    private var POOL: ThreadPoolExecutor? = null
    private val times = SparseArray<Long>()

    /**
     * GC阈值
     */
    private const val MAX = (1024 * 1024 * 32 * 10).toLong()

    /**
     * 当前待回收内存大小
     */
    private var sum: Long = 0
    private var cleaner: Method? = null
    private var clean: Method? = null
    private var heightDefault = 300
    private var widthDefault = 300

    init {
        //Android7.0及以后的版本,DirectByteBuffer可以手动释放内存
        //但api为隐藏,需要使用反射
        try {
            var clazz = Class.forName("java.nio.DirectByteBuffer")
            cleaner = clazz.getDeclaredMethod("cleaner")
            cleaner?.isAccessible = true
            clazz = Class.forName("sun.misc.Cleaner")
            clean = clazz.getDeclaredMethod("clean")
            clean?.isAccessible = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
        POOL = ThreadPoolExecutor(
            CORE_POOL_SIZE, MAXIMUM_POOL_SIZE, KEEP_ALIVE_SECONDS.toLong(), TimeUnit.SECONDS,
            SynchronousQueue(), sThreadFactory
        )
        POOL!!.rejectedExecutionHandler = sRunOnSerialPolicy
    }

    private fun getCacheDir(context: Context): String {
        if (root == null) {
            root = File(getFileRoot(context))
        }
        val file = File(root, CACHE_DIRECTORY)
        if (!file.exists()) {
            val isMake = file.mkdirs()
            Log.i("TAG", "isMake is $isMake")
        }
        return file.absolutePath
    }

    fun createBitmapList(
        context: Context?,
        scanFiles: List<String>,
        cacheMedia: MutableList<Bitmap>,
    ){
        require(!(context == null || scanFiles.isEmpty())) { "context or scanFiles is null" }
        val widthX = context.dp2px(widthDefault.toFloat())
        val heightX = context.dp2px(heightDefault.toFloat())
        val scope = CoroutineScope(Dispatchers.Default)
        scope.launch {
            val bitmapJobs = scanFiles.map { path ->
                async {
                    createBitmap(
                        context, widthX,
                        heightX,
                        path
                    )
                }
            }
            bitmapJobs.awaitAll().forEach {
                it?.let { bitmap ->
                    cacheMedia.add(bitmap)
                }
            }

            if (bitmapJobs.size == scanFiles.size) {
                LocalPictureLoader.isReady = true
                FlowBus.with<MutableList<Bitmap>>(EVENT_CACHE_MEDIA)
                    .post(ProxyApplication.mainScope, cacheMedia)
            }
        }
    }

    /**
     * 获取缩略图
     *
     * @param context 上下文
     * @param path    图片的路径
     * @return
     */
    private fun createBitmap(context: Context?, widthX: Int, heightX: Int, path: String): Bitmap? {
        if (context == null) {
            return null
        }
        val bitmap: Bitmap?
        val name = "$path-$widthX-$heightX".hashCode()
        val cacheFile = File(getCacheDir(context), name.toString() + "")
        if (cacheFile.exists()) {
            val buffer = IOUtils.mapFile(cacheFile.absolutePath) !!
            val width = buffer.int
            val height = buffer.int
            bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            buffer.clear()
            recycleBuffer(buffer)
            Log.e("yuli", "createBitmap: $width $height $widthX $heightX")
        } else {
            bitmap = decodeSampledBitmap(path, widthX, heightX)
        }
        if (!cacheFile.exists()) {
            if (bitmap == null) {
                return null
            }
            val buffer = ByteBuffer.allocate(bitmap.byteCount)
            val w = bitmap.width
            val h = bitmap.height
            bitmap.copyPixelsToBuffer(buffer)
            try {
                cacheFile.createNewFile()
            } catch (e: IOException) {
                throw RuntimeException(e)
            }
            IOUtils.writeBitmap(cacheFile.absolutePath, w, h, buffer.array())
            buffer.clear()
        }
        return bitmap
    }

    private fun decodeSampledBitmap(filePath: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(filePath, options)
        val width = options.outWidth
        val height = options.outHeight
        val inSampleSizeW = width / reqWidth
        val inSampleSizeH = height / reqHeight
        options.inSampleSize =
            if (inSampleSizeW > inSampleSizeH) inSampleSizeW else inSampleSizeH
        options.inJustDecodeBounds = false
        return BitmapFactory.decodeFile(filePath, options)
    }

    fun compressQuality(bitmap: Bitmap, quality: Int): Bitmap {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        val compressedData = outputStream.toByteArray()
        return BitmapFactory.decodeByteArray(compressedData, 0, compressedData.size)
    }

    private fun recycleBuffer(buffer: ByteBuffer) {
        if (cleaner == null || clean == null) {
            return
        }
        POOL!!.execute {
            try {
                sum += buffer.capacity().toLong()
                clean!!.invoke(cleaner!!.invoke(buffer))
                if (sum > MAX) {
                    System.gc()
                    sum = 0
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun getFileRoot(context: Context): String {
        if (Environment.getExternalStorageState() ==
            Environment.MEDIA_MOUNTED
        ) {
            val external = context.getExternalFilesDir(null)
            context.externalCacheDir
            if (external != null) {
                return external.absolutePath
            }
        }
        return context.filesDir.absolutePath
    }

    fun getExternalCacheDir(context: Context): String {
        if (Environment.getExternalStorageState() ==
            Environment.MEDIA_MOUNTED
        ) {
            val external = context.externalCacheDir
            if (external != null) {
                return external.absolutePath
            }
        }
        return context.filesDir.absolutePath
    }
}