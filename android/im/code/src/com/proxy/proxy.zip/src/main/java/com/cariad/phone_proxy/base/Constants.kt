package com.cariad.phone_proxy.base

const val PORT_ALBUM = 1234

const val PORT_SENSOR = 1235

const val BRIDGE_CHANNEL_ID = "channel_bridge"

const val FOREGROUND_CHANNEL_ID = "1186668"

const val BRIDGE_CHANNEL_NAME = "BridgeService"

const val ACTION_BOOT = "data.action.boot"
const val ACTION_BATTERY = "data.action.battery"
const val ACTION_NOTIFY = "data.action.notify"
const val ACTION_CREATE_NOTIFY = "data.action.create_notify"

const val BRIDGE_NOTIFICATION_ID = 1

const val CACHE_DIRECTORY = "phoneCache"