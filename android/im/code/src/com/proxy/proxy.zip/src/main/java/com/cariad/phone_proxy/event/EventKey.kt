package com.cariad.phone_proxy.event

val EVENT_IP_CHANGE = "ip-change"
val EVENT_BLUETOOTH_DEVICE = "BluetoothDevice"
val EVENT_BLUETOOTH_SCAN = "BlueScanFinish"
val EVENT_CHANNEL = "channel"
val EVENT_CACHE_MEDIA = "cache_media"