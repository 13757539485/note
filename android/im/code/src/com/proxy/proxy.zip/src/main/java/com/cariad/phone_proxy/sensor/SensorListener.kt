package com.cariad.phone_proxy.sensor

import com.cariad.m2.netty.base.SimpleListener

interface SensorListener: SimpleListener {
    fun messageReceived(msg: String)
}