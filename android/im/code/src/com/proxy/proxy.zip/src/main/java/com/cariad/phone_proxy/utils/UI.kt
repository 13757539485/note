package com.cariad.phone_proxy.utils

import android.app.Activity
import android.app.ActivityManager
import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import com.cariad.phone_proxy.base.ProxyApplication

private const val TAG = "UIExt"

fun Context.toast(content: CharSequence) {
    Toast.makeText(this, content, Toast.LENGTH_LONG).show()
}

fun Context.dp2px(dipValue: Float): Int {
    val scale = resources.displayMetrics.density
    return (dipValue * scale + 0.5f).toInt()
}

fun View.click(listener: (view: View) -> Unit) {
    val minTime = 500L
    var lastTime = 0L
    this.setOnClickListener {
        val tmpTime = System.currentTimeMillis()
        if (tmpTime - lastTime > minTime) {
            lastTime = tmpTime
            listener.invoke(this)
        } else {
            Log.d("UI", "点击过快，取消触发")
        }
    }
}

/**
 * 查询自身应用是否在电池优化白名单列表中
 */
fun Context.checkBatteryOptimizeEnable(): Boolean {
    val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager?
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        powerManager?.isIgnoringBatteryOptimizations(packageName) ?: false
    } else {
        true
    }
}

/**
 * 跳转或者请求电池白名单列表
 */
fun Application.openBatteryDialog() {
    val intent = Intent()
    if ("vivo" == Build.BRAND) {
        intent.action = Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS
    } else {
        intent.action = Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
        intent.data = Uri.parse("package:$packageName")
    }
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        startActivity(intent)
    } catch (e: Exception) {
        Log.e(TAG, "openBatteryDialog: " + e.message)
    }
}

/**
 * 跳转到系统设置界面：自启动管理界面
 */
fun Application.openSettingForBootPermission() {
    var intent: Intent?
    var startSuccess: Boolean = false
    SettingsAction.getBootAction()?.forEach { action: String ->
        if (startSuccess) return@forEach
        if (action.contains("/")) {
            intent = Intent()
            intent!!.component =
                ComponentName.unflattenFromString(action)
        } else {
            intent = packageManager.getLaunchIntentForPackage(action)
        }
        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
            startSuccess = true
        } catch (e: Exception) {
            startSuccess = false
            Log.e(TAG, "Not found in actions: " + e.message)
        }
    }
    if (!startSuccess) {
        intent = Intent().apply {
            action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            data = Uri.parse("package:$packageName")
        }
        intent!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Start default action fail: " + e.message)
        }
    }
}

/**
 * 判断是否为主进程
 */
fun Application.isMainProcess(): Boolean {
    val pid = android.os.Process.myPid()
    val process = (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).let {
        it.runningAppProcesses.filter { info -> pid == info.pid }[0]
    }
    return process.processName == packageName
}

/**
 * 检查通知权限是否开启
 */
fun Context.checkNotificationEnable() =
    NotificationManagerCompat.from(this).areNotificationsEnabled()

/**
 * 跳转到通知权限管理界面
 */
fun Application.openNotification() {
    val intent = Intent().apply {
        action = SettingsAction.getNotificationAction()
        putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        putExtra(Settings.EXTRA_CHANNEL_ID, applicationInfo.uid)
    }
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        startActivity(intent)
    } catch (e: Exception) {
        Log.e(TAG, "Start notification action fail: " + e.message)
    }
}

/**
 * 禁用Activity组件
 */
fun Activity.closeComponent() {
    packageManager.setComponentEnabledSetting(
        ComponentName(packageName, this::class.java.name),
        PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
    )
}

fun Activity.saveScreenInfo() {
    var screenWidth: Int
    var screenHeight: Int

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        windowManager.currentWindowMetrics.apply {
            screenWidth = bounds.width()
            screenHeight = bounds.height()
        }
    } else {
        windowManager.defaultDisplay.apply {
            val dm = DisplayMetrics()
            getRealMetrics(dm)
            screenWidth = dm.widthPixels
            screenHeight = dm.heightPixels
        }
    }
    if (screenWidth == 0) {
        screenWidth = resources.displayMetrics.widthPixels
    }
    if (screenHeight == 0) {
        screenHeight = resources.displayMetrics.heightPixels
    }
    ProxyApplication.screenWidth = screenWidth
    ProxyApplication.screenHeight = screenHeight
}