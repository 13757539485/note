package com.cariad.phone_proxy.album

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.cariad.phone_proxy.base.ProxyApplication
import com.ts.aiimage.IImageMsgUpdateListener
import com.ts.aiimagelib.AiImageMsgManger
import com.ts.aiimagelib.IConStatusListener

object AiImage : IConStatusListener {
    private val TAG = "AiImage"
    private var isConnectAiImageApp = false

    /**
     * 当有图片生成时回调
     */
    private val imageUpdateListener: IImageMsgUpdateListener by lazy {
        object : IImageMsgUpdateListener.Stub() {
            override fun onImageMsgUpdate(event: String, imageMsg: String) {
                Log.i(TAG, "onImageMsgUpdate event: $event, imageMsg: $imageMsg")
                MediaScannerConnection.scanFile(
                    ProxyApplication.application,
                    arrayOf(imageMsg),
                    arrayOf("image/jpeg")
                ) { path: String?, uri: Uri? ->
//                    GalleryLanServerTask.INSTANCE.catchAigcImageAndSend(imageMsg)
                }
            }
        }
    }

    /**
     * 初始化调用，绑定activity生命周期，自动管理sdk
     *
     * @param context 上下文
     * @param lifecycle 由activity/fragment传入
     */
    fun connect(context: Context, lifecycle: Lifecycle) {
        lifecycle.addObserver(object : LifecycleEventObserver {
            override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
                if (event == Lifecycle.Event.ON_DESTROY) {
                    AiImageMsgManger.getInstatnce().unInit()
                    lifecycle.removeObserver(this)
                } else if (event == Lifecycle.Event.ON_CREATE) {
                    AiImageMsgManger.getInstatnce().init(context, this@AiImage)
                }
            }
        })
    }

    /**
     * 本地单张图片生成生成ai图片接口
     *
     * @param imagePath 本地图片地址
     */
    fun sendImage(imagePath: String) {
        if (!isConnectAiImageApp) {
            Log.e(TAG, "sendImages error, call connect() first")
            return
        }
        Log.i(TAG, "sendImages: $imagePath")
        AiImageMsgManger.getInstatnce().getGenerateImage(imagePath)
    }

    /**
     * 本地多张图片生成生成ai图片接口
     *
     * @param imagePaths 本地多张图片地址，仅限3张
     */
    fun sendImages(imagePaths: List<String>) {
        if (!isConnectAiImageApp) {
            Log.e(TAG, "sendImages error, call connect() first")
            return
        }
        if (imagePaths.size != 3) {
            Log.e(TAG, "sendImages error, imagePaths size must be three: ${imagePaths.size}")
            return
        }
        Log.i(TAG, "sendImages: $imagePaths")
        AiImageMsgManger.getInstatnce()
            .getSynthesisImage(imagePaths[0], imagePaths[1], imagePaths[2])
    }

    /**
     * 用于取消图片生成
     */
    fun cancel() {
        if (!isConnectAiImageApp) {
            Log.e(TAG, "cancel fail, call connect() first")
            return
        }
        AiImageMsgManger.getInstatnce().cancel()
//        GalleryLanServerTask.INSTANCE.onAiMergeCanceled()
    }

    /**
     * sdk状态改变回调
     *
     * @param isConnect sdk连接是否建立
     */
    override fun onConStatus(isConnect: Boolean) {
        isConnectAiImageApp = isConnect
        if (isConnect) {
            AiImageMsgManger.getInstatnce()
                .registerListener(ProxyApplication.application.packageName, imageUpdateListener)
        } else {
            AiImageMsgManger.getInstatnce()
                .unregisterListener(ProxyApplication.application.packageName, imageUpdateListener)
        }
    }
}