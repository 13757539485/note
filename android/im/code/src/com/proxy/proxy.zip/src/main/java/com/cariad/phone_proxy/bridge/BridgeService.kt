package com.cariad.phone_proxy.bridge

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.cariad.phone_proxy.IBridgeService
import com.cariad.phone_proxy.R
import com.cariad.phone_proxy.base.ACTION_BATTERY
import com.cariad.phone_proxy.base.ACTION_BOOT
import com.cariad.phone_proxy.base.ACTION_CREATE_NOTIFY
import com.cariad.phone_proxy.base.ACTION_NOTIFY
import com.cariad.phone_proxy.base.BRIDGE_CHANNEL_ID
import com.cariad.phone_proxy.base.BRIDGE_CHANNEL_NAME
import com.cariad.phone_proxy.base.BRIDGE_NOTIFICATION_ID
import com.cariad.phone_proxy.base.ProxyApplication
import com.cariad.phone_proxy.utils.checkBatteryOptimizeEnable
import com.cariad.phone_proxy.utils.checkNotificationEnable
import com.cariad.phone_proxy.utils.openBatteryDialog
import com.cariad.phone_proxy.utils.openNotification
import com.cariad.phone_proxy.utils.openSettingForBootPermission

class BridgeService : Service() {
    companion object {
        const val TAG = "BridgeService"
    }

    private val notificationManager by lazy {
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    override fun onBind(intent: Intent?): IBinder {
        Log.i(TAG, "onBind: ")
        return object : IBridgeService.Stub() {

        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "onCreate: ")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "onStartCommand: $intent")
        intent?.let {
            when (it.action) {
                ACTION_BOOT -> ProxyApplication.application.openSettingForBootPermission()
                ACTION_BATTERY -> ProxyApplication.application.openBatteryDialog()
                ACTION_NOTIFY -> ProxyApplication.application.openNotification()
                ACTION_CREATE_NOTIFY -> createNotificationForForegroundService()
//                null -> startScanLocalMedias()
            }
        }
        return START_STICKY
    }

    @SuppressLint("RemoteViewLayout")
    fun createNotificationForForegroundService() {
        // 适配8.0及以上
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            notificationManager.getNotificationChannel(BRIDGE_CHANNEL_ID) == null
        ) {
            val channel = NotificationChannel(
                BRIDGE_CHANNEL_ID,
                BRIDGE_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        // 适配12.0及以上
        val flag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        // 添加自定义通知view
        val views = RemoteViews(packageName, R.layout.notification_bridge)
        // 打开自启管理
        val intentBoot = Intent(ACTION_BOOT)
        val pendingIntentBoot = PendingIntent.getBroadcast(
            this,
            0, intentBoot, flag
        )
        views.setOnClickPendingIntent(R.id.btnBoot, pendingIntentBoot)

        // 打开后台耗电界面
        val intentBattery = Intent(ACTION_BATTERY)
        val pendingIntentBattery = PendingIntent.getBroadcast(
            this,
            0, intentBattery, flag
        )
        views.setOnClickPendingIntent(R.id.btnBattery, pendingIntentBattery)
        views.setViewVisibility(
            R.id.btnBattery,
            if (checkBatteryOptimizeEnable()) View.GONE else View.VISIBLE
        )

        // 打开通知管理界面
        val intentNotify = Intent(ACTION_NOTIFY)
        val pendingIntentNotify = PendingIntent.getBroadcast(
            this,
            0, intentNotify, flag
        )
        views.setOnClickPendingIntent(R.id.btnNotify, pendingIntentNotify)
        views.setViewVisibility(
            R.id.btnNotify,
            if (checkNotificationEnable()) View.GONE else View.VISIBLE
        )

        // 创建Builder
        val builder: NotificationCompat.Builder = NotificationCompat.Builder(
            this,
            BRIDGE_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setAutoCancel(true)
            .setCustomContentView(views)
            .setPriority(1000)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else {
            0
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(BRIDGE_NOTIFICATION_ID, builder.build(), type)
        }
    }
}