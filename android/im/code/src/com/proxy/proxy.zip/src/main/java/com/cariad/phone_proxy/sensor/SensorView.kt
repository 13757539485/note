package com.cariad.phone_proxy.sensor

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import com.cariad.phone_proxy.base.ProxyApplication
import com.cariad.phone_proxy.base.BaseView
import com.cariad.phone_proxy.base.FlowBus
import com.cariad.phone_proxy.databinding.SensorBinding
import com.cariad.phone_proxy.event.ChannelEvent
import com.cariad.phone_proxy.event.EVENT_CHANNEL

class SensorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : BaseView(context, attrs, defStyleAttr) {
    private val binding: SensorBinding

    init {
        binding = SensorBinding.inflate(LayoutInflater.from(context), this)
        binding.btnSensorConnect.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                binding.textShowMsg.text = "建立连接中"
                if (ProxyApplication.IP.isNotBlank()) {
                    SensorExtManager.start(ProxyApplication.IP)
                }
            } else {
                if (buttonView.isPressed) {
                    SensorExtManager.close()
                    binding.textShowMsg.text = "关闭连接"
                }
            }
        }
        FlowBus.with<ChannelEvent>(EVENT_CHANNEL).register(this) {
            if (it.active) {
                binding.textShowMsg.text = "建立连接完成"
            } else {
                when (it.msg) {
                    "ConnectException" -> {
                        binding.btnSensorConnect.isChecked = false
                        binding.textShowMsg.text = "服务器端未启动"
                    }

                    else -> {
                        binding.btnSensorConnect.isChecked = false
                        binding.textShowMsg.text = "服务器端关闭"
                    }
                }
            }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        SensorExtManager.close()
    }
}