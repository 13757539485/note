package com.cariad.phone_proxy.sensor

import android.content.Context
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import android.util.SparseArray
import androidx.core.util.forEach
import androidx.core.util.getOrDefault
import com.cariad.phone_proxy.base.ProxyApplication
import com.cariad.phone_proxy.base.FlowBus
import com.cariad.phone_proxy.base.PORT_SENSOR
import com.cariad.phone_proxy.event.ChannelEvent
import com.cariad.phone_proxy.event.EVENT_CHANNEL
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

object SensorExtManager {
    private const val TAG: String = "SensorExtManager"

    private val mainScope by lazy { MainScope() }

    private val cacheCallbacks by lazy { SparseArray<SensorCallback>() }

    private val sensorManager by lazy { ProxyApplication.application.getSystemService(Context.SENSOR_SERVICE) as SensorManager }

    private val sensorCacheManager by lazy {
        SensorCacheManager().also {
            it.typeUnUseListener = { type ->
                unRegisterSensorListener(type, typeToListener(type, ""))
            }
        }
    }

    private val sensorHandler by lazy { SensorHandler() }

    private val imListener by lazy {
        object : SensorListener {
            override fun messageReceived(msg: String) {
                mainScope.launch {
                    analysisMsg(msg)
                }
            }

            override fun channelActive() {
                FlowBus.with<ChannelEvent>(EVENT_CHANNEL).post(mainScope, ChannelEvent.obtainEvent()
                    .also {
                        it.active = true
                    })
            }

            override fun channelInActive(msg: String) {
                FlowBus.with<ChannelEvent>(EVENT_CHANNEL).post(mainScope, ChannelEvent.obtainEvent()
                    .also {
                        it.active = false
                        it.msg = msg
                    })
                releaseAll()
            }
        }
    }

    fun start(ip: String) {
        sensorHandler.registerListener(imListener)
        sensorHandler.startClient(ip, PORT_SENSOR)
    }

    fun close() {
        sensorHandler.close()
    }

    fun sendMsg(msg: String) {
        sensorHandler.sendMsg(msg)
    }

    private fun typeToListener(type: Int, handle: String): SensorCallback {
        val callback =
            cacheCallbacks.getOrDefault(type, SensorCallback().also { it.handle = handle })
        cacheCallbacks[type] = callback
        return callback
    }

    private fun analysisMsg(msg: String) {
        val cmd = msg.split(":")
        try {
            val flag = cmd[0]
            if ("enable" == flag) {
                val type = cmd[1].toInt()
                val uid = cmd[3].toInt()
                val handle = cmd[2]
                val listener = typeToListener(type, handle)
                registerSensorListener(type, listener)
                sensorCacheManager.enable(type, uid)
            } else if ("disable" == flag) {
                val type = cmd[1].toInt()
                val uid = cmd[2].toInt()
                sensorCacheManager.disable(type, uid)
            } else if ("state" == flag) {
                val active = cmd[2] == "active"
                if (!active) {
                    val uid = cmd[1].toInt()
                    sensorCacheManager.state(uid)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun registerSensorListener(type: Int, listener: SensorEventListener?) {
        if (listener == null) {
            Log.e(TAG, "sensor listener is null")
            return
        }
        if (sensorCacheManager.hasEnable(type)) {
            Log.e(TAG, "sensor has register")
            return
        }
        sensorManager.registerListener(
            listener,
            sensorManager.getDefaultSensor(type),
            SensorManager.SENSOR_DELAY_NORMAL
        )
        Log.e(TAG, "sensor register: $type")
    }

    private fun unRegisterSensorListener(type: Int, listener: SensorEventListener?) {
        if (listener == null) {
            Log.e(TAG, "sensor listener is null")
            return
        }
        if (sensorCacheManager.hasEnable(type)) {
            Log.e(TAG, "sensor has no register")
            return
        }
        sensorManager.unregisterListener(listener)
        Log.e(TAG, "sensor unregister: $type")
    }

    private fun releaseAll() {
        cacheCallbacks.forEach { _, value ->
            sensorManager.unregisterListener(value)
        }
        cacheCallbacks.clear()
        sensorCacheManager.clear()
        Log.i(TAG, "releaseAll: ")
    }
}