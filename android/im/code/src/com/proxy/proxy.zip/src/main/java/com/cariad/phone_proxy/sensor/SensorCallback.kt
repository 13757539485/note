package com.cariad.phone_proxy.sensor

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.util.Log

class SensorCallback : SensorEventListener {
    private val TAG = "SensorCallback"

    var handle: String = ""

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            sendSensorData(it, handle)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        Log.d(TAG, "onAccuracyChanged: type ${sensor?.type},accuracy $accuracy")
    }

    private fun sendSensorData(event: SensorEvent, handle: String) {
        if (handle.isEmpty()) {
            Log.d(TAG, "sendSensorData: handle is null")
            return
        }
        val builder = StringBuilder()
        builder.append(event.sensor.type).append(":")
            .append(handle).append(":")
            .append(event.accuracy).append(":")
            .append(event.timestamp)
        event.values.forEach {
            builder.append(":").append(it)
        }
        SensorExtManager.sendMsg(builder.toString())
    }
}