package com.cariad.phone_proxy.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Parcelable
import android.util.Log
import com.cariad.phone_proxy.base.ProxyApplication
import com.cariad.phone_proxy.base.FlowBus
import com.cariad.phone_proxy.event.EVENT_BLUETOOTH_DEVICE
import com.cariad.phone_proxy.event.EVENT_BLUETOOTH_SCAN

/**
 * 监听发现蓝牙的广播
 *
 */
@SuppressLint("MissingPermission")
class BluetoothReceiver : BroadcastReceiver() {
    private val TAG = "BlueToothReceiver"
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            BluetoothDevice.ACTION_ACL_CONNECTED -> Log.d(TAG, "ACTION_ACL_CONNECTED")
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> Log.d(
                TAG,
                "ACTION_ACL_DISCONNECTED"
            ) // 连接断开，停止通信
            BluetoothDevice.ACTION_FOUND -> {
                // 找到设备
                intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)?.let {
                    FlowBus.with<BluetoothDevice>(EVENT_BLUETOOTH_DEVICE).post(ProxyApplication.mainScope, it)
                }
            }

            BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                // 远程设备的绑定状态发生变化
                Log.d(TAG, "ACTION_BOND_STATE_CHANGED")
                when ((intent.getParcelableExtra<Parcelable>(BluetoothDevice.EXTRA_DEVICE) as BluetoothDevice?)!!.bondState) {
                    BluetoothDevice.BOND_NONE -> {}
                    BluetoothDevice.BOND_BONDING -> {}
                    BluetoothDevice.BOND_BONDED -> {}
                }
            }

            BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                Log.d(TAG, "ACTION_DISCOVERY_FINISHED")
                FlowBus.with<Boolean>(EVENT_BLUETOOTH_SCAN).post(ProxyApplication.mainScope, false)
            }

            BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                Log.d(TAG, "ACTION_DISCOVERY_FINISHED")
                FlowBus.with<Boolean>(EVENT_BLUETOOTH_SCAN).post(ProxyApplication.mainScope, true)
            }
        }
    }

    companion object {
        /**
         * 设置Intent过滤器
         *
         * @return
         */
        fun markFilter(): IntentFilter {
            val filter = IntentFilter()
            filter.addAction(BluetoothDevice.ACTION_FOUND)
            filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
            filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            return filter
        }
    }
}
