package com.cariad.phone_proxy

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.BitmapTransitionOptions
import com.cariad.m2.netty.pack.ByteArrayMessage
import com.cariad.phone_proxy.databinding.ItemBlueBinding
import com.cariad.phone_proxy.databinding.ItemImgBinding
import com.chad.library.adapter4.BaseQuickAdapter
import java.io.ByteArrayOutputStream

class ImageAdapter: BaseQuickAdapter<String, ImageAdapter.VH>() {
    class VH(
        parent: ViewGroup,
        val binding: ItemImgBinding = ItemImgBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        ),
    ) : RecyclerView.ViewHolder(binding.root)

    override fun onBindViewHolder(holder: VH, position: Int, item: String?) {
        item?.let {
            Log.e("thth", "onBindViewHolder: $it")
//            ByteArrayOutputStream().use { baos ->
//                val bitmap = BitmapFactory.decodeByteArray(it.data, 0, it.data.size)
//                holder.binding.itemImg.setImageBitmap(bitmap)
            holder.binding.itemImg.load(it)
        }
//        }
    }

    override fun onCreateViewHolder(context: Context, parent: ViewGroup, viewType: Int): VH {
        return VH(parent)
    }
}