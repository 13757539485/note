package com.cariad.phone_proxy.utils

import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.Flushable
import java.io.InputStream
import java.io.RandomAccessFile
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

object IOUtils {
    fun mapFile(path: String?): MappedByteBuffer? {
        val file = File(path)
        return mapFile(path, file.length())
    }

    private fun mapFile(path: String?, size: Long): MappedByteBuffer? {
        var accessFile: RandomAccessFile? = null
        var channel: FileChannel? = null
        var buffer: MappedByteBuffer? = null
        try {
            accessFile = RandomAccessFile(path, "rw")
            channel = accessFile.channel
            buffer = channel.map(FileChannel.MapMode.READ_WRITE, 0, size).load()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            close(accessFile, channel)
        }
        return buffer
    }

    fun writeBitmap(path: String?, width: Int, height: Int, data: ByteArray?) {
        var fos: FileOutputStream? = null
        var dos: DataOutputStream? = null
        try {
            fos = FileOutputStream(path)
            dos = DataOutputStream(fos)
            dos.writeInt(width)
            dos.writeInt(height)
            dos.write(data)
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            close(fos, dos)
        }
    }

    fun readByte(path: String?): ByteArray? {
        var `is`: InputStream? = null
        var data: ByteArray? = null
        var baos: ByteArrayOutputStream? = null
        try {
            `is` = FileInputStream(path)
            baos = ByteArrayOutputStream()
            val b = ByteArray(102400)
            var len = 0
            while (`is`.read(b).also { len = it } != -1) {
                baos.write(b, 0, len)
            }
            data = baos.toByteArray()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            close(`is`, baos)
        }
        return data
    }

    fun close(vararg closeables: Closeable?) {
        if (closeables == null) {
            return
        }
        for (closeable in closeables) {
            if (closeable == null) {
                continue
            }
            try {
                if (closeable is Flushable) {
                    (closeable as Flushable).flush()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                closeable.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}