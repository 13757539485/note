package com.cariad.phone_proxy.bridge

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.IBinder
import android.util.Log
import com.cariad.phone_proxy.IBridgeService
import com.cariad.phone_proxy.base.ACTION_CREATE_NOTIFY
import com.cariad.phone_proxy.base.ProxyApplication

object ServiceManager {
    private const val TAG = "ServiceManager"
    private var proxyService: IBridgeService? = null
    private val serviceConnection by lazy {
        object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                service?.let {
                    proxyService = IBridgeService.Stub.asInterface(service)
                }
                Log.e(TAG, "onServiceConnected: $proxyService")
                startService()
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                proxyService = null
                bindService()
            }
        }
    }

    fun bindService() {
        if (proxyService != null) {
            Log.i(TAG, "Service already bind")
            startService()
            return
        }
        val intent = Intent(ProxyApplication.application, BridgeService::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ProxyApplication.application
            .bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun startService() {
        val intent = Intent(ProxyApplication.application, BridgeService::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.action = ACTION_CREATE_NOTIFY
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ProxyApplication.application.startForegroundService(intent)
        } else {
            ProxyApplication.application.startService(intent)
        }
    }

    fun getBinder() = proxyService
}