package com.cariad.phone_proxy.event

class ChannelEvent {
    var active: Boolean = false
    var msg: String = ""

    companion object {
        private var event: ChannelEvent? = null

        fun obtainEvent(): ChannelEvent {
            if (event == null) {
                event = ChannelEvent()
            }
            return event!!
        }
    }
}
