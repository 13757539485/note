package com.cariad.phone_proxy

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.bitmap.BitmapTransitionOptions
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.cariad.m2.netty.im.ImClientHandler
import com.cariad.phone_proxy.album.LocalPictureLoader
import com.cariad.phone_proxy.album.LocalPictureLoader.mediaToByteArrayMessage
import com.cariad.phone_proxy.base.FlowBus
import com.cariad.phone_proxy.bluetooth.BluetoothExtManager
import com.cariad.phone_proxy.databinding.ActivityMainBinding
import com.cariad.phone_proxy.event.EVENT_CACHE_MEDIA
import com.cariad.phone_proxy.event.EVENT_IP_CHANGE
import com.cariad.phone_proxy.utils.saveScreenInfo
import com.hjq.permissions.XXPermissions
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }
    private val imClient by lazy { ImClientHandler() }
    private val imgAdapter by lazy { ImageAdapter() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        saveScreenInfo()
        BluetoothExtManager.init(this)
        val startTime = System.currentTimeMillis()
        LocalPictureLoader.init(this)

        binding.imgRv.adapter = imgAdapter
        FlowBus.with<String>(EVENT_IP_CHANGE).register(this) {
            binding.sensorView.isVisible = it.isNotEmpty()
        }
        FlowBus.with<MutableList<Bitmap>>(EVENT_CACHE_MEDIA).register(this) {
            binding.tempShow.text =
                "加载${it.size}张图片耗时: ${System.currentTimeMillis() - startTime}"
        }
        imgAdapter.setOnItemClickListener { _, _, position ->
            val imgPath = imgAdapter.getItem(position) as String

            val rootImg = ImageView(this)

            rootImg.setOnClickListener {
                (window.decorView as ViewGroup).removeView(rootImg)
            }
            (window.decorView as ViewGroup).apply {
                addView(rootImg,
                    FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT))
                Glide.with(this)
                    .asBitmap()
                    .load(imgPath)
                    .thumbnail(
                        Glide.with(this)
                        .asBitmap()
                        .load(imgPath)
                        .apply(RequestOptions().sizeMultiplier(0.02f))
                    )
                    .skipMemoryCache(true)
                    .transition(BitmapTransitionOptions.withCrossFade().crossFade(500))
                    .into(rootImg)
            }
        }
        binding.tempShow.setOnClickListener {
            lifecycleScope.launch {
                val startTime = System.currentTimeMillis()
                val temp = LocalPictureLoader.mediaToByteArrayMessage()
                binding.tempShow.text = "耗时: ${System.currentTimeMillis() - startTime}"
                imgAdapter.submitList(LocalPictureLoader.gainOriImgPath())
            }

            /*imClient.startClient("192.168.137.40", 1234)
            imClient.registerListener(object : ImListener {
                override fun messageReceived(bitmap: Bitmap) {

                }

                override fun messageReceived(msg: String) {
                    binding.tempShow.text = msg
                }

                override fun channelActive() {
                    val temp = LocalPictureLoader.mediaToByteArrayMessage()
//                    imClient.sendMsg(temp)
//                    imgAdapter.submitList(temp)

                    lifecycleScope.launch {
                        withContext(Dispatchers.Main) {
                            binding.tempShow.text = System.currentTimeMillis().toString()
                        }
                    }
                }

                override fun channelInActive(msg: String) {

                }
            })*/
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        BluetoothExtManager.destroy(this)
        imClient.close()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            BluetoothExtManager.FLAG_GPS, BluetoothExtManager.FLAG_BLUETOOTH, XXPermissions.REQUEST_CODE -> {
                BluetoothExtManager.init(this)
            }
        }
    }
}