package com.cariad.phone_proxy.base

import android.app.Application
import com.cariad.phone_proxy.bridge.ServiceManager
import com.cariad.phone_proxy.utils.isMainProcess
import kotlinx.coroutines.MainScope

class ProxyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        application = this
        if (isMainProcess()) {
            ServiceManager.bindService()
        }
    }

    companion object {
        lateinit var application: Application
        var IP: String = ""
        val mainScope = MainScope()
        var screenWidth: Int = 0
        var screenHeight: Int = 0
    }
}
