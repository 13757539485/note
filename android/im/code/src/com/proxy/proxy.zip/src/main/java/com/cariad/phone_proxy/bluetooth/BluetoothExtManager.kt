package com.cariad.phone_proxy.bluetooth

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.cariad.phone_proxy.utils.toast
import com.hjq.permissions.OnPermissionCallback
import com.hjq.permissions.Permission
import com.hjq.permissions.XXPermissions

@SuppressLint("MissingPermission")
object BluetoothExtManager {
    private val TAG = "BluetoothExtManager"
    private val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
    private var receiver: BluetoothReceiver? = null
    const val FLAG_GPS = 50
    const val FLAG_BLUETOOTH = 51

    fun getBondedDevices(): MutableSet<BluetoothDevice>? =
        bluetoothAdapter.bondedDevices

    fun scanBluetooth() {
        if (bluetoothAdapter.isDiscovering) {
            bluetoothAdapter.cancelDiscovery()
        }
        bluetoothAdapter.startDiscovery()
    }

    fun bluetoothConnected(device: BluetoothDevice): Boolean {
        return try {
            BluetoothDevice::class.java
                .getDeclaredMethod("isConnected")
                .let {
                    it.isAccessible = true
                    it.invoke(device) as Boolean
                }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun getConnectDevice(): BluetoothDevice? {
        return bluetoothAdapter.bondedDevices.filter {
            bluetoothConnected(it)
        }.getOrNull(0)
    }

    fun init(activity: Activity) {
        XXPermissions.with(activity)
            .permission(Permission.ACCESS_FINE_LOCATION)
            .permission(Permission.Group.BLUETOOTH)
            .permission(Permission.POST_NOTIFICATIONS)
            .request(object : OnPermissionCallback {

                @RequiresApi(Build.VERSION_CODES.TIRAMISU)
                override fun onGranted(permissions: MutableList<String>, allGranted: Boolean) {
                    if (!allGranted) {
                        activity.toast("获取部分权限成功，但部分权限未正常授予")
                        return
                    }
                    if (checkGps(activity)) {
                        // 创建指向系统定位服务设置的Intent
                        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                        // 启动该Intent，用户将被带到系统设置中的定位服务页面
                        activity.startActivityForResult(intent, FLAG_GPS)
                    } else {
                        if (!bluetoothAdapter.isEnabled) {
                            activity.startActivityForResult(
                                Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),
                                FLAG_BLUETOOTH
                            )
                        } else {
                            initBluetooth(activity)
                        }
                    }
                }

                override fun onDenied(permissions: MutableList<String>, doNotAskAgain: Boolean) {
                    activity.toast("获取权限失败或被永久拒绝授权，请手动授予位和附近的设备权限")
                    XXPermissions.startPermissionActivity(activity, permissions)
                }
            })
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun initBluetooth(activity: Activity) {
        receiver = BluetoothReceiver()
        activity.registerReceiver(
            receiver,
            BluetoothReceiver.markFilter(), Context.RECEIVER_EXPORTED
        )
        scanBluetooth()
    }

    private fun checkGps(activity: Activity): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val lm: LocationManager =
                activity.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            return if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                Toast.makeText(
                    activity,
                    "请您先开启gps,否则蓝牙不可用",
                    Toast.LENGTH_SHORT
                ).show()
                true
            } else {
                false
            }
        } else {
            false
        }
    }

    fun destroy(activity: Activity) {
        receiver?.let {
            activity.unregisterReceiver(it)
        }
        if (bluetoothAdapter.isDiscovering) {
            bluetoothAdapter.cancelDiscovery()
        }
    }
}