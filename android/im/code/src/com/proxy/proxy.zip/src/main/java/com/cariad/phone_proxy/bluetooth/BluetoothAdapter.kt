package com.cariad.phone_proxy.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.cariad.bluetooth_base.BluetoothListener
import com.cariad.bluetooth_base.BtClient
import com.cariad.phone_proxy.base.ProxyApplication
import com.cariad.phone_proxy.databinding.ItemBlueBinding
import com.cariad.phone_proxy.utils.click
import com.chad.library.adapter4.BaseQuickAdapter

class BluetoothAdapter(
    blueBeans: MutableList<BluetoothDevice>,
    private val block: (isConnected: Boolean, msg: String) -> Unit
) :
    BaseQuickAdapter<BluetoothDevice, BluetoothAdapter.VH>(blueBeans) {
    class VH(
        parent: ViewGroup,
        val binding: ItemBlueBinding = ItemBlueBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        ),
    ) : RecyclerView.ViewHolder(binding.root)

    private val TAG = "BluetoothAdapter"
    private var btClient: BtClient? = null

    @SuppressLint("MissingPermission")
    override fun onBindViewHolder(holder: VH, position: Int, item: BluetoothDevice?) {
        item?.let { blueDev ->
            holder.binding.blueItemAddrTv.text = blueDev.address
            holder.binding.blueItemNameTv.text = blueDev.name
            holder.binding.blueItemStatusTv.apply {
                /*if (BluetoothExtManager.bluetoothConnected(blueDev)) {
                    holder.binding.blueItemStatusTv.text = "已连接"
                    block(true, App.IP)
                } else */
                if (blueDev.bondState == BluetoothDevice.BOND_BONDED) {
                    text = "(已配对)"
                    setTextColor(Color.parseColor("#ff009688"))
                } else {
                    text = "(未配对)"
                    setTextColor(Color.parseColor("#ffFF5722"))
                }
            }
            holder.itemView.click {
                btClient = BtClient(blueDev, object : BluetoothListener {
                    override fun onStart() {
                        holder.binding.blueItemStatusTv.text = "正在连接..."
                    }

                    override fun onMsgRecv(socket: BluetoothSocket?, msg: String) {
                        block(true, msg)
                        Log.e(TAG, "onMsgRecv: $msg")
                    }

                    override fun onError(error: String) {
                        block(false, error)
                        holder.binding.blueItemStatusTv.text = "(已配对)"
                    }

                    override fun onConnected(msg: String) {
                        holder.binding.blueItemStatusTv.text = "已连接"
                        block(true, ProxyApplication.IP)
                        Log.e(TAG, "onConnected: $msg")
                    }
                }).also {
                    it.start()
                }
            }
        }
    }

    override fun onCreateViewHolder(context: Context, parent: ViewGroup, viewType: Int): VH {
        return VH(parent)
    }

    fun sendMsg(msg: String) {
        btClient?.sendMsg(msg)
    }

    fun close() {
        btClient?.close()
    }
}