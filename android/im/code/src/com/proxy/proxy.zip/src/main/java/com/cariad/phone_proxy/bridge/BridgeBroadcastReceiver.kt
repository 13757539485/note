package com.cariad.phone_proxy.bridge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class BridgeBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        context?.let {
            Toast.makeText(it, "我开机自启了", Toast.LENGTH_SHORT).show()
        }
        intent?.let {
            when (it.action) {
                Intent.ACTION_BOOT_COMPLETED -> {
                    ServiceManager.bindService()
                }
            }
        }
    }
}
