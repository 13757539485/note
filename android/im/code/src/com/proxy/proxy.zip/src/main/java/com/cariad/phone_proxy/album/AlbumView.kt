package com.cariad.phone_proxy.album

import android.content.Context
import android.util.AttributeSet
import com.cariad.phone_proxy.base.BaseView

class AlbumView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : BaseView(context, attrs, defStyleAttr) {
}