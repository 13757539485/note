package com.cariad.phone_proxy.utils

import android.os.Build
import android.provider.Settings

object SettingsAction {
    private val ACTION_BOOT_VIVO_SETTINGS: Array<String> by lazy {
        arrayOf(
            "com.vivo.permissionmanager/com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.iqoo.secure/com.iqoo.secure.ui.phoneoptimize.BgStartUpManager",
            "com.iqoo.secure/com.iqoo.secure.safeguard.PurviewTabActivity",
            "com.iqoo.secure/com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"
        )
    }

    private val ACTION_BOOT_OPPO_SETTINGS: Array<String> by lazy {
        arrayOf(
            "com.coloros.safecenter/com.coloros.safecenter.permission.startup.FakeActivity",
            "com.coloros.safecenter/com.coloros.safecenter.permission.startupapp.StartupAppListActivity",
            "com.coloros.safecenter/com.coloros.safecenter.permission.startupmanager.StartupAppListActivity",
            "com.coloros.safecenter/com.coloros.safecenter.permission.startsettings",
            "com.coloros.safecenter/com.coloros.safecenter.permission.startupapp.startupmanager",
            "com.coloros.safecenter/com.coloros.safecenter.permission.startupmanager.startupActivity",
            "com.coloros.safecenter/com.coloros.safecenter.permission.startup.startupapp.startupmanager",
            "com.coloros.safecenter/com.coloros.privacypermissionsentry.PermissionTopActivity.Startupmanager",
            "com.coloros.safecenter/com.coloros.privacypermissionsentry.PermissionTopActivity",
            "com.coloros.safecenter/com.coloros.safecenter.FakeActivity",
            "com.coloros.safe/com.coloros.safe.permission.startup.StartupAppListActivity",
            "com.coloros.safe/com.coloros.safe.permission.startupapp.StartupAppListActivity",
            "com.coloros.safe/com.coloros.safe.permission.startupmanager.StartupAppListActivity",
            "com.coloros.safecenter/com.coloros.safecenter.startupapp.StartupAppListActivity",
            "com.coloros.safecenter/com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.oppo.safe/com.oppo.safe.permission.startup.StartupAppListActivity",
            "com.coloros.oppoguardelf/com.coloros.powermanager.fuelgaue.PowerUsageModelActivity"
        )
    }

    private val ACTION_BOOT_XIAOMI_SETTINGS: Array<String> by lazy {
        arrayOf("com.miui.securitycenter/com.miui.permcenter.autostart.AutoStartManagementActivity")
    }

    private val ACTION_BOOT_ONEPLUS_SETTINGS: Array<String> by lazy {
        arrayOf("com.oneplus.security/com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity")
    }

    private val ACTION_BOOT_MEIZU_SETTINGS: Array<String> by lazy {
        arrayOf(
            "com.meizu.safe/com.meizu.safe.permission.SmartBGActivity",
            "com.meizu.safe/com.meizu.safe.permission.PermissionMainActivity"
        )
    }

    private val ACTION_BOOT_HUAWEI_SETTINGS: Array<String> by lazy {
        arrayOf(
            "com.huawei.systemmanager/com.huawei.systemmanager.mainscreen.MainScreenActivity",
            "com.huawei.systemmanager/com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.huawei.systemmanager/com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity",
            "com.huawei.systemmanager/com.huawei.systemmanager.optimize.process.ProtectActivity",
            "com.huawei.systemmanager/com.huawei.systemmanager.optimize.bootstart.BootStartActivity",
            "com.huawei.systemmanager", "com.hihonor.systemmanager"
        )
    }

    private val ACTION_BOOT_SAMSUNG_SETTINGS: Array<String> by lazy {
        arrayOf(
            "com.samsung.android.sm_cn/com.samsung.android.sm.ui.ram.AutoRunActivity",
            "com.samsung.android.sm_cn/com.samsung.android.sm.ui.appmanagement.AppManagementActivity",
            "com.samsung.android.sm_cn/com.samsung.android.sm.ui.cstyleboard.SmartManagerDashBoardActivity",
            "com.samsung.android.sm_cn/com.samsung.android.sm_cn.ui.ram.RamActivity",
            "com.samsung.android.sm_cn/com.samsung.android.sm_cn.app.dashboard.SmartManagerDashBoardActivity",
            "com.samsung.android.sm/com.samsung.android.sm.ui.ram.AutoRunActivity",
            "com.samsung.android.sm/com.samsung.android.sm.ui.appmanagement.AppManagementActivity",
            "com.samsung.android.sm/com.samsung.android.sm.ui.cstyleboard.SmartManagerDashBoardActivity",
            "com.samsung.android.sm/com.samsung.android.sm.ui.ram.RamActivity",
            "com.samsung.android.sm/com.samsung.android.sm.app.dashboard.SmartManagerDashBoardActivity",
            "com.samsung.android.lool/com.samsung.android.sm.ui.battery.BatteryActivity",
            "com.samsung.android.lool/com.samsung.android.sm.battery.ui.BatteryActivity",
        )
    }

    private val ACTION_BOOT_HTC_SETTINGS: Array<String> by lazy {
        arrayOf(
            "com.htc.pitroad/com.htc.pitroad.landingpage.activity.LandingPageActivity",
        )
    }

    private val ACTION_BOOT_ZTE_SETTINGS: Array<String> by lazy {
        arrayOf(
            "com.zte.heartyservice/com.zte.heartyservice.autorun.AppAutoRunManager",
        )
    }

    private val ACTION_BOOT_SMARTISANOS_SETTINGS: Array<String> by lazy {
        arrayOf(
            "com.smartisanos.security/com.smartisanos.security.invokeHistory.InvokeHistoryActivity",
        )
    }

    private val ACTION_BOOT_LENOVO_SETTINGS: Array<String> by lazy {
        arrayOf(
            "com.lenovo.security/com.lenovo.security.purebackground.PureBackgroundActivity",
        )
    }

    private val ACTION_BOOT_ASUS_SETTINGS: Array<String> by lazy {
        arrayOf(
            "com.asus.mobilemanager/com.asus.mobilemanager.MainActivity"
        )
    }

    fun getBootAction(): Array<String>? {
        return when (Build.BRAND) {
            "vivo" -> ACTION_BOOT_VIVO_SETTINGS
            "xiaomi" -> ACTION_BOOT_XIAOMI_SETTINGS
            "meizu" -> ACTION_BOOT_MEIZU_SETTINGS
            "samsung" -> ACTION_BOOT_SAMSUNG_SETTINGS
            "huawei" -> ACTION_BOOT_HUAWEI_SETTINGS
            "oppo" -> ACTION_BOOT_OPPO_SETTINGS
            "htc" -> ACTION_BOOT_HTC_SETTINGS
            "oneplus" -> ACTION_BOOT_ONEPLUS_SETTINGS
            "lenovo" -> ACTION_BOOT_LENOVO_SETTINGS
            "asus" -> ACTION_BOOT_ASUS_SETTINGS
            "smartisanos" -> ACTION_BOOT_SMARTISANOS_SETTINGS
            "zte" -> ACTION_BOOT_ZTE_SETTINGS
            else -> null
        }
    }

    fun getNotificationAction(): String {
        return when (Build.BRAND) {
            "vivo" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
            else -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
        }
    }
}