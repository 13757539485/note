package com.cariad.phone_proxy.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.pm.PackageManager
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.cariad.bluetooth_base.isIPv4Address
import com.cariad.phone_proxy.base.ProxyApplication
import com.cariad.phone_proxy.base.BaseView
import com.cariad.phone_proxy.base.FlowBus
import com.cariad.phone_proxy.databinding.BluetoothBinding
import com.cariad.phone_proxy.event.EVENT_BLUETOOTH_DEVICE
import com.cariad.phone_proxy.event.EVENT_BLUETOOTH_SCAN
import com.cariad.phone_proxy.event.EVENT_IP_CHANGE
import com.cariad.phone_proxy.utils.click

@SuppressLint("MissingPermission")
class BluetoothView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : BaseView(context, attrs, defStyleAttr) {
    private val TAG = "BluetoothView"
    private val binding: BluetoothBinding
    private val blueBeans: MutableList<BluetoothDevice> by lazy { mutableListOf() }
    private var blueAdapter: BluetoothAdapter? = null

    init {
        binding = BluetoothBinding.inflate(LayoutInflater.from(context), this)

        binding.btnBtScan.click {
            blueBeans.clear()
            blueAdapter?.notifyDataSetChanged()
            BluetoothExtManager.scanBluetooth()
        }

        registerEvent()
        bindAdapter(context)
    }

    private fun registerEvent() {
        FlowBus.with<BluetoothDevice>(EVENT_BLUETOOTH_DEVICE).register(this) { blueDev ->
            if (blueDev !in blueBeans && blueDev.name != null) {
                blueBeans.add(blueDev)
                blueAdapter?.notifyItemInserted(blueBeans.size)
            }
        }

        FlowBus.with<Boolean>(EVENT_BLUETOOTH_SCAN).register(this) {
            binding.btnBtScan.text = if (it) "扫描" else "扫描中..."
            binding.btnBtScan.isEnabled = it
            if (!it) {
                addBondedDevices()
            }
        }
    }

    private fun bindAdapter(context: Context) {
        val manager = LinearLayoutManager(context)
        binding.btRv.layoutManager = manager
        blueAdapter = BluetoothAdapter(blueBeans, block = { isConnected, msg ->
            binding.textShowMsg.text = msg
            if (isConnected && isIPv4Address(msg)) {
                ProxyApplication.IP = msg
                FlowBus.with<String>(EVENT_IP_CHANGE).post(ProxyApplication.mainScope, msg)
            } else {
                ProxyApplication.IP = ""
                FlowBus.with<String>(EVENT_IP_CHANGE).post(ProxyApplication.mainScope, "")
            }
        })
        binding.btRv.adapter = blueAdapter
    }

    private fun addBondedDevices() {
        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        val bondedDevices = BluetoothExtManager.getBondedDevices()
        bondedDevices?.forEach { device ->
            blueBeans.add(device)
            blueAdapter?.notifyItemInserted(blueBeans.size)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        blueAdapter?.close()
    }
}