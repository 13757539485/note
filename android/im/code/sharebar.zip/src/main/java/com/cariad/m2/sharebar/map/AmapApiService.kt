package com.cariad.m2.sharebar.map

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * 高德地图api接口
 */
interface AmapApiService {
    /**
     * https://lbs.amap.com/api/webservice/guide/api-advanced/newpoisearch
     * 搜索poi2.0版本：关键字搜索
     */
    @GET("v5/place/text?parameters")
    suspend fun searchPlaces(
        @Query("key") key: String = "4d3a440539ea82e4e50c30e120ed95d2",
        @Query("keywords") keywords: String = "",
        @Query("page_num") page_num: Int = 1,
        @Query("page_size") page_size: Int = 1,
    ): Response<SearchResponse>
}