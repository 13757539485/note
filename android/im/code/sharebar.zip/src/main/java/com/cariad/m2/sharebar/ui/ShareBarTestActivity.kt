package com.cariad.m2.sharebar.ui

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.cariad.m2.sharebar.core.ShareReceiver
import com.cariad.m2.sharebar.databinding.ActivitySharebarTestBinding
import com.cariad.m2.sharebar.map.Pois
import com.cariad.m2.sharebar.map.provideAmapRetrofit
import com.cariad.m2.sharebar.util.navigateInMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class ShareBarTestActivity : AppCompatActivity() {
    private val binding by lazy { ActivitySharebarTestBinding.inflate(layoutInflater) }
    private val amapApiService by lazy { provideAmapRetrofit() }

    private var pois: Pois? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.showTaskIsland.setOnClickListener {
            sendBroadToHideShareBar(true)
        }
        binding.hideTaskIsland.setOnClickListener {
            sendBroadToHideShareBar(false)
        }
        binding.btnMapSearch.setOnClickListener {
            lifecycleScope.launch {
                try {
                    val response = amapApiService.searchPlaces(
                        keywords = "浙江省杭州市上城区平安金融中心B座"
                    )
                    if (response.isSuccessful) {
                        pois = response.body()?.pois?.get(0)
                        withContext(Dispatchers.Main) {
                            binding.mapShow.text = pois.toString()
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        binding.btnMapNavigate.setOnClickListener {
            pois?.let {
                val loc = it.location.split(",")
                if (loc.isNotEmpty() && loc.size > 1) {
                    navigateInMap(this@ShareBarTestActivity, it.name, loc[1], loc[0])
                }
            }
        }
        /*binding.enableAccess.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }*/
    }

    private fun sendBroadToHideShareBar(isShow: Boolean) {
        val intent = Intent(if (isShow) "action.sharebar.show" else "action.sharebar.hide")
        intent.setComponent(
            ComponentName(
                "com.cariad.m2",
                "com.cariad.m2.sharebar.core.ShareReceiver"
            )
        )
        sendBroadcast(intent)
    }
}