package com.cariad.m2.sharebar.ui

import android.content.Context
import android.util.Log
import android.view.DragEvent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.cariad.m2.sharebar.databinding.ItemDragViewBinding
import com.cariad.m2.sharebar.util.PKG_GAODE
import com.cariad.m2.sharebar.util.ShareAppInfo
import com.cariad.m2.sharebar.util.navigate
import com.cariad.m2.sharebar.util.shareApp
import com.chad.library.adapter4.BaseQuickAdapter

/**
 * 任务岛列表适配器
 */
class ShareBarAdapter : BaseQuickAdapter<ShareAppInfo, ShareBarAdapter.VH>() {
    var dragListener: ((event: DragEvent) -> Unit)? = null

    class VH(
        parent: ViewGroup,
        val binding: ItemDragViewBinding = ItemDragViewBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        ),
    ) : RecyclerView.ViewHolder(binding.root)

    override fun onBindViewHolder(holder: VH, position: Int, item: ShareAppInfo?) {
        item?.let {
            holder.binding.root.setItemName(it.label)
            holder.binding.root.setItemIcon(it.icon)
        }
        holder.itemView.setOnClickListener {
            item?.let {
                Log.e(
                    "ShareBarAdapter", "onBindViewHolder: " +
                            "${it.packageName} " +
                            "${it.className}  ${it.customUri}"
                )
            }
        }
        holder.binding.root.registerDragListener { event ->
            if (event.action == DragEvent.ACTION_DROP) {
                val mimeType = event.clipData.description.getMimeType(0)
                val itemOne = event.clipData.getItemAt(0)
                item?.let {
                    if (it.customUri) {
                        if (it.packageName == PKG_GAODE) {
                            navigate(context, itemOne.text)
                        }
                    } else {
                        shareApp(
                            context,
                            mimeType,
                            it.packageName,
                            it.className,
                            itemOne.text,
                            itemOne.uri
                        )
                    }
                }
            }
            dragListener?.invoke(event)
        }
    }

    override fun onCreateViewHolder(context: Context, parent: ViewGroup, viewType: Int): VH {
        return VH(parent)
    }
}