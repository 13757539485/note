package com.cariad.m2.sharebar.core

import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.IBinder
import android.util.Log
import android.view.DragEvent
import android.view.LayoutInflater
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.cariad.m2.sharebar.databinding.WindowShareBarBinding
import com.cariad.m2.sharebar.databinding.WindowShareBarCardBinding
import com.cariad.m2.sharebar.ui.ShareBarAdapter
import com.cariad.m2.sharebar.ui.ShareBarWindowManager
import com.cariad.m2.sharebar.util.ACTION_SHARE_BAR_CARD_SHOW
import com.cariad.m2.sharebar.util.ACTION_SHARE_BAR_CUSTOM_PKG_DRAG
import com.cariad.m2.sharebar.util.ACTION_SHARE_BAR_HIDE
import com.cariad.m2.sharebar.util.ACTION_SHARE_BAR_SHOW
import com.cariad.m2.sharebar.util.ALLOW_PKG_SHARE_LIST
import com.cariad.m2.sharebar.util.ALL_TYPE
import com.cariad.m2.sharebar.util.GAODE_SEARCH_CLASS
import com.cariad.m2.sharebar.util.MEITU_SHARE_CLASS
import com.cariad.m2.sharebar.util.PKG_GAODE
import com.cariad.m2.sharebar.util.PKG_MEITU
import com.cariad.m2.sharebar.util.ShareAppInfo
import com.cariad.m2.sharebar.util.dp2px
import com.cariad.m2.sharebar.util.navigate
import com.cariad.m2.sharebar.util.px2dp
import com.cariad.m2.sharebar.util.shareApp
import java.util.Arrays

/**
 * 用来管理任务岛的服务类
 */
class ShareBarService : Service() {
    companion object {
        private const val TAG = "ShareBarService"
    }

    private val windowBing by lazy { WindowShareBarBinding.inflate(LayoutInflater.from(this)) }
    private val cardBing by lazy { WindowShareBarCardBinding.inflate(LayoutInflater.from(this)) }
    private val shareBarAdapter by lazy { ShareBarAdapter() }

    override fun onBind(p0: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowBing.shareBarList.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        windowBing.shareBarList.adapter = shareBarAdapter
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            when (intent.action) {
                ACTION_SHARE_BAR_SHOW -> {
                    val type = it.clipData?.let { clipData ->
                        if (clipData.description == null) {
                            ALL_TYPE
                        } else {
                            val mimeTypeCount = clipData.description.mimeTypeCount
                            if (mimeTypeCount > 0) {
                                clipData.description.getMimeType(0)
                            } else {
                                ALL_TYPE
                            }
                        }
                    } ?: ALL_TYPE
                    Log.e(TAG, "onStartCommand show bar type: $type")
                    shareBarAdapter.submitList(queryAppInfo(type))
                    ShareBarWindowManager.create(windowBing.root)
                }

                ACTION_SHARE_BAR_HIDE -> {
                    ShareBarWindowManager.dismiss()
                }

                ACTION_SHARE_BAR_CARD_SHOW -> {
                    cardShow(it)
                }

                ACTION_SHARE_BAR_CUSTOM_PKG_DRAG -> {
                    customDrag(it)
                }

                else -> {}
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    /**
     * 接收由手机端直接发送的信息，只支持调用高德地图处理
     */
    private fun cardShow(intent: Intent) {
        ShareBarWindowManager.create(
            cardBing.root,
            tag = ShareBarWindowManager.TAG_SHARE_BAR_CARD,
            params = ShareBarWindowManager.cardParams()
        )
        cardBing.cardImg.setImageBitmap(null)
        if (intent.data == null) {
            cardBing.firstText.isVisible = true
            cardBing.secondText.isVisible = true
            cardBing.cardImg.layoutParams.apply {
                width = dp2px(this@ShareBarService, 400f)
                height = dp2px(this@ShareBarService, 180f)
            }
        } else {
            cardBing.firstText.isVisible = false
            cardBing.secondText.isVisible = false
            contentResolver.openInputStream(intent.data!!)?.use {
                val bitmap = BitmapFactory.decodeStream(it)
                cardBing.cardImg.layoutParams.apply {
                    width = px2dp(this@ShareBarService, bitmap.width.toFloat())
                    height = px2dp(this@ShareBarService, bitmap.height.toFloat())
                }
                cardBing.cardImg.setImageBitmap(bitmap)
            }
        }
        intent.getStringExtra("text")?.let { text ->
            val content = text.split("\r?\n".toRegex())
            if (content.size > 1) {
                cardBing.firstText.text = content[0]
                cardBing.secondText.text = content[1]
            }
            cardBing.root.setOnClickListener {
                shareApp(
                    this@ShareBarService,
                    "text/plain",
                    PKG_GAODE,
                    GAODE_SEARCH_CLASS,
                    if (intent.data == null) content[1] else content[0],
                    null
                )
                ShareBarWindowManager.dismiss(ShareBarWindowManager.TAG_SHARE_BAR_CARD)
            }
        }
    }

    /**
     * 自定义应用窗口支持拖拽功能，支持列表由framework中{@link CariadDragHelper#handleDragEvent}决定
     */
    private fun customDrag(intent: Intent) {
        // 如果是高德或者美图执行分享功能
        val pkg = intent.getStringExtra("target_pkg") // 拖拽结束时所处的应用包名
        intent.clipData?.let {
            if (PKG_GAODE == pkg && it.itemCount > 0) {
                val itemAt = it.getItemAt(0)
                itemAt.text?.let { text ->
                    navigate(this@ShareBarService, text)
                }
            } else if (PKG_MEITU == pkg && it.itemCount > 0) {
                val itemAt = it.getItemAt(0)
                itemAt.uri?.let { uri ->
                    shareApp(
                        this@ShareBarService,
                        "image/*",
                        PKG_MEITU,
                        MEITU_SHARE_CLASS,
                        null, uri
                    )
                }
            } else {
                Log.e(TAG, "hide pkg: $pkg")
                intent.clipData?.let {
                    it.description?.let { desc ->
                        for (i in 0..<desc.mimeTypeCount) {
                            val itemAt = desc.getMimeType(i)
                            Log.e(TAG, "desc: $itemAt")
                        }
                    }

                    for (i in 0..<it.itemCount) {
                        val itemAt = it.getItemAt(i)
                        Log.e(
                            TAG, "clip: ${itemAt.text} " +
                                    "${itemAt.uri} "
                        )
                    }
                }
            }
        }
    }

    /**
     * 系统查询接口
     *
     * @param type 通过type查询支持分享的应用集合，
     * "*\/\*"表示所有类型,
     * "text/\*"表示文本类型,
     * "image/\*"表示图片类型
     *
     * @return 分享应用集合
     */
    private fun queryAppInfo(type: String): List<ShareAppInfo> {
        val intent = Intent(Intent.ACTION_SEND, null)
        intent.addCategory(Intent.CATEGORY_DEFAULT)
        intent.setType(type)
        // 过滤需要的应用
        val list = mutableListOf<ShareAppInfo>()
        packageManager.queryIntentActivities(
            intent,
            PackageManager.COMPONENT_ENABLED_STATE_DEFAULT
        ).filter {
            ALLOW_PKG_SHARE_LIST.contains(it.activityInfo.packageName)
        }.forEach {
            if (it.activityInfo.packageName == PKG_GAODE) {
                list.add(
                    ShareAppInfo(
                        it.loadIcon(packageManager),
                        "${it.loadLabel(packageManager)}搜索",
                        it.activityInfo.packageName,
                        it.activityInfo.name
                    )
                )
                list.add(
                    ShareAppInfo(
                        it.loadIcon(packageManager),
                        "${it.loadLabel(packageManager)}导航",
                        it.activityInfo.packageName,
                        it.activityInfo.name, true
                    )
                )
            } else {
                list.add(
                    ShareAppInfo(
                        it.loadIcon(packageManager),
                        it.loadLabel(packageManager),
                        it.activityInfo.packageName,
                        it.activityInfo.name
                    )
                )
            }
        }
        return list
    }
}